import requests

def get_characters(page=1):
    url = f"https://rickandmortyapi.com/api/character/?page={page}"
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        return data
    else:
        print(f"Erro ao fazer a requisição: {response.status_code}")
        return None

def search_characters(name):
    url = f"https://rickandmortyapi.com/api/character/?name={name}"
    response = requests.get(url)

    if response.status_code == 200:
        data = response.json()
        return data
    else:
        print(f"Erro ao fazer a requisição: {response.status_code}")
        return None

def display_characters(data):
    if 'results' not in data or not data['results']:
        print("Nenhum personagem encontrado.")
        return

    for character in data['results']:
        name = character['name']
        status = character['status']
        species = character['species']
        gender = character['gender']
        image = character['image']
        print(f"Nome: {name}, Status: {status}, Espécie: {species}, Gênero: {gender}")
        print(f"Imagem: {image}\n")

def main():
    while True:
        search = input("Deseja buscar um personagem? (s/n): ").strip().lower()
        if search == 's':
            name = input("Digite o nome do personagem: ")
            characters_data = search_characters(name)
            display_characters(characters_data)
        elif search == 'n':
            page = 1
            while True:
                characters_data = get_characters(page)
                if characters_data:
                    display_characters(characters_data)
                    if characters_data['info']['next']:
                        page += 1
                        input("Pressione Enter para carregar a próxima página...")
                    else:
                        print("Não há mais páginas.")
                        break
                else:
                    break
        else:
            print("Opção inválida. Tente novamente.")

if __name__ == "__main__":
    main()
